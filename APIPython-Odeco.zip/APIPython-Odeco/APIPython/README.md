# APIAutomation_Summer2020


To download a copy of this project please install git client from here:

https://desktop.github.com/

Once git client is installed, please open a command line application (cmd or terminal) and navigate to a location on you hard drive where you would like to store this project.  
Use the `cd` command followed by the absolute or relative path to the desired location:

Example:

    cd ~/Portnov/classes

Once in position, execute the following command:

    git clone https://github.com/EllieSky/APIAutomation_Summer2020.git

After the command completes, you should have a copy of the project code.

Now in PyCharm you can open the project by selecting the top most folder.

To create your own personal branch, in PyCharm open Terminal (bottom tab):

    git checkout -b <your_personal_branch_name>


After every class (the next day):

    git fetch
    
    git checkout <your_branch_name>
    
    git rebase origin/master


