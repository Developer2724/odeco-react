export const types = {
  BOOLEAN: 'boolean',
  STRING: 'string',
  TIMESTAMP: 'timestamp'
};