import App from "containers/App/App.jsx";

const indexRoutes = [{ path: "/", component: App }];

export default indexRoutes;
