// Returns a mock data of all clients in a database.
export function getClientsFromDatabase() {
  const clients = [
    [1, "Guilherme Herzog", "guihermeherzog@gmail.com", "+55 (21) 979 366 060", "Stadthausbrücke 5, 20355, Hamburg"],
    [2, "Marcelo Herzog", "marcelo.herzog@gmail.com", "+55 (21) 979 366 060", "Stadthausbrücke 5, 20355, Hamburg"],
    [3, "Viktoria Arndt", "viktoria.arndt@gmail.com", "+55 (21) 979 366 060", "Stadthausbrücke 5,20355, Hamburg"],
    [4, "Andrea Frank", "andrea.frank@gmail.com", "+55 (21) 979 366 060", "Stadthausbrücke 5, 20355, Hamburg"],
    [5, "Andrea Frank", "andrea.frank@gmail.com", "+55 (21) 979 366 060", "Stadthausbrücke 5, 20355, Hamburg"],
    [6, "Andrea Frank", "andrea.frank@gmail.com", "+55 (21) 979 366 060", "Stadthausbrücke 5, 20355, Hamburg"],
    [7, "Andrea Frank", "andrea.frank@gmail.com", "+55 (21) 979 366 060", "Stadthausbrücke 5, 20355, Hamburg"],
    [8, "Andrea Frank", "andrea.frank@gmail.com", "+55 (21) 979 366 060", "Stadthausbrücke 5, 20355, Hamburg"],
    [9, "Andrea Frank", "andrea.frank@gmail.com", "+55 (21) 979 366 060", "Stadthausbrücke 5, 20355, Hamburg"],
    [10, "Andrea Frank", "andrea.frank@gmail.com", "+55 (21) 979 366 060", "Stadthausbrücke 5, 20355, Hamburg"],
    [11, "Andrea Frank", "andrea.frank@gmail.com", "+55 (21) 979 366 060", "Stadthausbrücke 5, 20355, Hamburg"],
    [12, "Andrea Frank", "andrea.frank@gmail.com", "+55 (21) 979 366 060", "Stadthausbrücke 5, 20355, Hamburg"],
    [13, "Lukas Herzog", "lukas.herzog@gmail.com", "+55 (21) 979 336 123", "Stadthausbrücke 5, 20355, Hamburg"]
  ];

  return clients;
}